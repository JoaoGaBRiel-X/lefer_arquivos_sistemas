using System;
using XDPeople.Data;
using XDPeople.Utils;

namespace XRest{
	//Obrigatório
	public class Script
	{
	//A função Execute é obrigatória em todos os scripts. É a partir de aqui que todo o código do script vai ser chamado.
	    public static void Execute(ScriptHost host)
	    {
			try{
				
				//Mensagem a pedir para confirmar
				if(MessageDG.ShowQuestionYesNo(null,"SCRIPT TESTE", "Este script ira apagar todos os plus e familias da base de dados. Deseja continuar?" ) == MessageDG.MessageResponse.Yes){
					
					//Apaga plus da base de dados
					Db.CurrentDatabase.ExecuteCommand ("delete from items;");
					
					//Apaga familias da base de dados
					Db.CurrentDatabase.ExecuteCommand ("delete from itemsGroups;");

					//Comando para compactar e optimizar a base de dados (SQLite)
					if(IniFile.DbType == 2){
						Db.CurrentDatabase.ExecuteCommand ("VACUUM;");
					}
					
					//Mensagem de sucesso
					MessageDG.ShowSuccess(null,"Titulo", "Comando sql executado com sucesso");
				}
			}
			catch(Exception e){
				Console.WriteLine(e);
				
				//Mensagem de aviso
				MessageDG.ShowExclamation(null, "Titulo", "Não foi possivel executar o comando sql");
				
			}
	    }
	}
}

