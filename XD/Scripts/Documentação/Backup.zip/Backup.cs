using System;
using Ionic.Zip;
using ICSharpCode.SharpZipLib;
using System.IO;

namespace XRest{
	//Obrigatório
	public class Script
	{
		//A função Execute é obrigatória em todos os scripts. É a partir de aqui que todo o código do script vai ser chamado.
		public static void Execute(ScriptHost host)
		{
			try{

				//Caminho para onde o ficheiro de backup será guardado
				string path = "C:\\";

				//Caminho da pasta db e dbconf do software XD
				string dbPath = System.IO.Path.GetFullPath ("..//..//db");
				string dbconfPath = System.IO.Path.GetFullPath ("..//..//dbconf");
				
				//Construir nome do ficheiro com a data actual
				string OutPutDirectoryFile = "";
				if (path.EndsWith (System.IO.Path.DirectorySeparatorChar.ToString ())) {
					OutPutDirectoryFile = path + @"backup-" + DateTime.Now.Day.ToString () + "-" + DateTime.Now.Month.ToString () + "-" + DateTime.Now.Year.ToString () + "_" + 
						DateTime.Now.Hour.ToString () + "-" + DateTime.Now.Minute.ToString () + "-" + DateTime.Now.Second.ToString () + ".zip";
				} else {
					OutPutDirectoryFile = path + System.IO.Path.DirectorySeparatorChar + @"backup-" + DateTime.Now.Day.ToString () + "-" + DateTime.Now.Month.ToString () + "-" + DateTime.Now.Year.ToString () + "_" + 
						DateTime.Now.Hour.ToString () + "-" + DateTime.Now.Minute.ToString () + "-" + DateTime.Now.Second.ToString () + ".zip";
				}
				
				//Cria ficheiro Zip e adiciona os conteudos necessarios
				using (Ionic.Zip.ZipFile zip = new Ionic.Zip.ZipFile()) {
					
					if (dbPath.Contains ("..//")) {
						dbPath = System.IO.Path.GetFullPath (dbPath.Substring (dbPath.IndexOf ("..//")));
					}
					
					int dbcpos = dbconfPath.LastIndexOf (System.IO.Path.DirectorySeparatorChar);
					string dbcrelative = dbconfPath.Substring (dbcpos + 1);
					
					//Adiciona os directórios ao ficheiro zip
					zip.AddDirectory (dbPath, "db");
					zip.AddDirectory (dbconfPath, dbcrelative);

					//Grava o ficheiro zip
					zip.Save (OutPutDirectoryFile);
					
				}
				
			}
			catch(Exception e){
				Console.WriteLine(e);
				
			}
		}
	}
}

