using System;
using Gtk;
using System.Data;
using XDPeople.Data;
using XDPeople.Entities;
using XDPeople.Business;

//o compo namespace é obrigatório para o script correr no XD
namespace XRest{
	//É Obrigatório o Campo class Script para executar a função Script
	public class Script
	{
		private static Entry txtOriginalNumber;
		private static Entry txtFinalNumber;
		private static Window window;
		
		//A função Execute é obrigatória em todos os scripts. É a partir daqui que todo o código do script vai ser chamado.
	    public static void Execute(ScriptHost host)
	    {
			try
			{
				ShowWindow();				 
								
			}
			catch(Exception e)
			{
				MessageDG.ShowError(null, "XD", e.ToString());
				//Não é obrigatório inserir código aqui
				//aqui colocamos o código que pretendemos executar em caso de algum erro ter ocorrido por exemplo mostrar mensagem com o erro que ocorreu				
			}
			finally
			{
				//Não é obrigatório inserir código aqui
				//aqui colocamo o código que queremos que execute mesmo que aconteça algum erro
			}
	    }		
		
		private static void ShowWindow()
		{
			Label title1 = new Label("Introduza o numero de cliente que pretende alterar");
			txtOriginalNumber = new Entry();
			txtOriginalNumber.SetSizeRequest(100,30);
			txtOriginalNumber.Xalign = 1;
			
			Label title2 = new Label("Introduza o novo numero de cliente");
			txtFinalNumber = new Entry();
			txtFinalNumber.SetSizeRequest(100,30);
			txtFinalNumber.Xalign = 1;
			
		 	window = new Window("Mudar Numero Cliente");
			window.WindowPosition = WindowPosition.CenterAlways;
			VBox vbox = new VBox();
			vbox.PackStart(title1, true,true,5);
			vbox.PackStart(txtOriginalNumber, false, false, 5);
			vbox.PackStart(title2, true, true, 5);
			vbox.PackStart(txtFinalNumber, false, false, 5);
			
			HBox hbox = new HBox();
			Button btOk = new Button("Confirmar");
			
			btOk.Clicked += ConfirmFunc;
			
			Button btCancel = new Button("Cancelar");
			btCancel.Clicked += delegate {
				window.Destroy();
			};
			hbox.PackStart(btOk, true, true, 10);
			hbox.PackStart(btCancel, true,true, 10);
			
			vbox.PackStart(hbox,true,true,10);
			window.Add(vbox);
			
			window.ShowAll();
		}
		
		protected static void ConfirmFunc(object sender, EventArgs args)
		{
			CustomerBO customerController = new CustomerBO();
			
			int finalNumber;
			
			if(!Int32.TryParse(txtFinalNumber.Text, out finalNumber))
			{
				MessageDG.ShowError(null, "XD", "O Numero final nao e valido.");
				return;
			}
			
			Entity customer = customerController.DbSelect(txtFinalNumber.Text);
			if(customer != null)
			{
				MessageDG.ShowError(null, "XD", "Existe um Cliente com o novo Numero");
				return;				
			}
			
			string checkIfExists = "SELECT Count( EntityKeyId )"
								+ "  FROM  ( "
								+ "    SELECT EntityKeyId"
								+ "      FROM DocumentsHeaders "
								+ "    UNION ALL "
								+ "    SELECT EntityKeyId "
								+ "      FROM DocHeadersManual "
								+ "    UNION ALL "
								+ "    SELECT EntityKeyId "
								+ "      FROM DocHeadersCanceled "
								+ ") as Contagem "								
								+ " WHERE EntityKeyId = " + txtFinalNumber.Text + "; ";
				
				
				
				
			DataRow dr = Db.CurrentDatabase.GetDataRow(checkIfExists);
						
			int finalNumberExistes = 0;
			
			int.TryParse(dr[0].ToString(), out finalNumberExistes);
			
			if(finalNumberExistes > 0)
			{
				MessageDG.ShowError(null, "XD", "Existem Faturas com o novo Numero");
				return;
			}
			
			customer = customerController.DbSelect(txtOriginalNumber.Text);
			
			customer.KeyId = txtFinalNumber.Text;
			
			customerController.DbUpdate(customer);
			
			
			string sqlUpdateHeaders = "UPDATE documentsheaders "
									+ "   SET EntityKeyId = '"+txtFinalNumber.Text+"' "
									+ " WHERE EntityKeyID = '"+txtOriginalNumber.Text+"'; "
									+ " "
									+ "UPDATE docHeadersManual "
									+ "   SET EntityKeyId = '"+txtFinalNumber.Text+"' "
									+ " WHERE EntityKeyID = '"+txtOriginalNumber.Text+"';"
									+ " "
									+ "UPDATE docHeadersCanceled "
									+ "   SET EntityKeyId = '"+txtFinalNumber.Text+"' "
									+ " WHERE EntityKeyID = '"+txtOriginalNumber.Text+"';"
									+ " "
									+ "UPDATE documentsbodys "
									+ "   SET EntityKeyId = '"+txtFinalNumber.Text+"' "
									+ " WHERE EntityKeyID = '"+txtOriginalNumber.Text+"';"
									+ " "
									+ "UPDATE docbodysManual "
									+ "   SET EntityKeyId = '"+txtFinalNumber.Text+"' "
									+ " WHERE EntityKeyID = '"+txtOriginalNumber.Text+"';"
									+ " "
									+ "UPDATE docBodysCanceled "
									+ "   SET EntityKeyId = '"+txtFinalNumber.Text+"' "
									+ " WHERE EntityKeyID = '"+txtOriginalNumber.Text+"';";
			
			int res = Db.CurrentDatabase.ExecuteCommand(sqlUpdateHeaders);	
					
			if(MessageDG.ShowInfo(null, "XD", "Alteracao Executada com sucesso. Numero de documentos afectados: " + res ) == MessageDG.MessageResponse.Ok)
				window.Destroy();
		}
	}
}
