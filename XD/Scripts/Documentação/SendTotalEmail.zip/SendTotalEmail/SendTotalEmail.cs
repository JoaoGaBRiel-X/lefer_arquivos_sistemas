using System;
using System.Data;
using Mono.Data.Sqlite;
using System.Net;
using System.Net.Mail;
using System.Security.Cryptography.X509Certificates;
using System.Net.Security;
using XDPeople.Data;

namespace XRest
{
	public class Script
	{
		public static void Execute (ScriptHost host)
		{
			//Data de hoje
			string date = DateTime.Now.Year + "-" + DateTime.Now.Month.ToString("00") + "-" + DateTime.Now.Day.ToString("00");
			
			//Comando sql para ir buscar o total de vendas à base de dados xd
			string SQLQuery = "SELECT "
				+ "SUM(Total) AS Total "
					+ "FROM DocumentsHeaders "
					+ "WHERE (date(CloseDate) = '" + date + "');";
			
			System.Data.DataTable tmpDataTabel = Db.CurrentDatabase.GetDataTable(SQLQuery);
			
			decimal temp = 0;

			//Guarda os registos que foi buscar à base de dados na variável temp
			foreach(DataRow myRow in tmpDataTabel.Rows)
			{
				Decimal.TryParse(myRow[0].ToString(), out temp);
			}

			//Configurações de email para gmail(exemplo)
			string smtpServer = "smtp.gmail.com"; //Servidor que envia o email
			string smtpSender = "xdtray@gmail.com"; //Quem vai enviar o email
			string smtpTo = "exemplo@gmail.com"; //Quem vai receber o email
			string smtpUser = "xdtray@gmail.com"; // User que envia o email. Igual ao enderço no caso do gmail
			string smtpPassword = "xdtraytest"; //Password de quem envia o email
			int smtpPort = 587; //Porta do servidor que envia o email

			//Constrói email
			MailMessage mail = new MailMessage();
			
			SmtpClient SmtpServer = new SmtpClient(smtpServer);
			
			mail.From = new MailAddress(smtpSender);
	
			mail.To.Add(smtpTo);
			
			mail.Subject = "Total do dia " + DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss"); //Assunto
			
			mail.Body = "Total de vendas até ao momento: " + temp; //temp contém o total de vendas que foi encontrado na base de dados
			
			SmtpServer.Port = smtpPort;
			
			// Adiciona certificado para os servidores que precisam
			SmtpServer.Credentials = new System.Net.NetworkCredential(smtpUser, smtpPassword);
			
			SmtpServer.EnableSsl = true;
			ServicePointManager.ServerCertificateValidationCallback = delegate(object s, X509Certificate certificate, X509Chain chain, SslPolicyErrors sslPolicyErrors) { return true; };
			
			//Envia o email
			SmtpServer.Send(mail);

		}

	}
}

