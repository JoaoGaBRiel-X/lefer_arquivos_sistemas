using System;
using XDPeople.Data;

namespace XRest{

     //Obrigat�rio
     public class Script
     {
         //A fun��o Execute � obrigat�ria em todos os scripts. � a partir de aqui que todo o c�digo do script vai ser chamado.
         public static void Execute(ScriptHost host)
         {
               try
               {
                     //Mensagem a pedir para confirmar
                     if(MessageDG.ShowQuestionYesNo(null,"SCRIPT TESTE", "Esta Op�ao ira colocar os precos em Sistema de Semana - Preco 1. Deseja continuar?" ) == MessageDG.MessageResponse.Yes){

                          //Apaga plus da base de dados
                          Db.CurrentDatabase.ExecuteCommand ("update Happyhour set price = 1;");
                          MainWindow.LoadListHappyHour();

                          //Mensagem de sucesso
                          MessageDG.ShowSuccess(null,"Titulo", "Precos de Semana (1) Activados com Sucesso");
                     }
               }
               catch(Exception e){

                     Console.WriteLine(e);

                     //Mensagem de aviso
                     MessageDG.ShowExclamation(null, "Titulo", "N�o foi possivel executar o comando sql");
               }
         }
     }
}

