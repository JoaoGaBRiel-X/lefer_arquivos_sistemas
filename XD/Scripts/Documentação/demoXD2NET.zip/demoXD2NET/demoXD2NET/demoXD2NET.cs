using System;
using System.Data;
using Mono.Data.Sqlite;
using XDPeople.Data;

namespace XRest{
	//Obrigatório
	public class Script
	{
	//A função Execute é obrigatória em todos os scripts. É a partir de aqui que todo o código do script vai ser chamado.
	    public static void Execute(ScriptHost host)
	    {
			//Variáveis que irão guardar as estatisticas necessárias
			DataTable queryResultDT = new DataTable();
			decimal totalIncomeForPaid = 0.0m;
			decimal totalIncomeForNonPaid = 0.0m;
			
			int totalNumberForPaid = 0;
			int totalNumberForNonPaid = 0;
						
			string docText = "";

			try{
				//SQL para obter todos os cartões utilizados
				string sqlQuery = "SELECT Id,Status,Total As Totals FROM XConfigSaleZonesAreaObjects WHERE Status <> 0";
				
				queryResultDT = Db.CurrentDatabase.GetDataTable(sqlQuery);
				
				if (queryResultDT != null)
				{
					
					// Para cada cartão
					for (int i = 0; i < queryResultDT.Rows.Count; i++)
					{
						int cardStatus  = int.Parse(queryResultDT.Rows[i][1].ToString());
						
						// Calcular o total de cartões não pagos
						if (cardStatus == 1 || cardStatus == 3 || cardStatus == 4) 
						{
							totalIncomeForNonPaid += decimal.Parse(queryResultDT.Rows[i][2].ToString());
							totalNumberForNonPaid ++;
						//Número de cartões pagos existentes
						}else if (cardStatus == 2)
						{
							totalNumberForPaid++;
						}
						
					}
					
					
					
					// SQL para obter total de cartões pagos
					
					sqlQuery =
						"SELECT SUM(Total) AS Total " +
						"FROM ( " +
						"	SELECT SaleZoneAreaObjectId, Total " +
						"	  FROM DocumentsHeaders " +
						"	 WHERE DocumentsHeaders.SaleZoneAreaObjectId IN ( " +
						" 			SELECT Id " +
						"			  FROM XConfigSaleZonesAreaObjects " +
						"			 WHERE Status = 2 ) " +
						" GROUP BY SaleZoneAreaObjectId " +
						" ORDER BY Id DESC " + 
						") AS View1 ";
					
					queryResultDT = Db.CurrentDatabase.GetDataTable(sqlQuery);
					
					//Se não existirem cartões pagos, coloca-se o valor a 0
					if(!decimal.TryParse(queryResultDT.Rows[0][0].ToString(), out totalIncomeForPaid)){
						
						totalIncomeForPaid = 0;
					}
					
					
					
					// Criação do texto referente a cartões
					docText = "<td width='85%'><font face='Arial' color='#FFFFFF'>Total de " + (totalNumberForPaid + totalNumberForNonPaid) + " cartões no valor de: </font></td><td width='15%'><font face='Arial' color='#FFFFFF'>" + (totalIncomeForPaid+totalIncomeForNonPaid) +
						"€</font></td>-<td width='85%'><font face='Arial' color='#FFFFFF'>" + totalNumberForPaid + " cartões pagos com um total de: </font></td><td width='15%'><font face='Arial' color='#FFFFFF'>" + Math.Round( totalIncomeForPaid, 2) +
							"€</font></td>-<td width='85%'><font face='Arial' color='#FFFFFF'>" + totalNumberForNonPaid + " cartões não pagos com um total de: </font></td><td width='15%'><font face='Arial' color='#FFFFFF'>" + Math.Round( totalIncomeForNonPaid, 2);
					
					docText = docText + "€</font></td>|";
					
					//SQL para obter a data de sessão actual
					sqlQuery = "SELECT SessionDate " +
						"FROM " +
							"XConfig";
					
					queryResultDT = Db.CurrentDatabase.GetDataTable(sqlQuery);
					
					string date = ((DateTime)queryResultDT.Rows[0][0]).ToString("yyyy-MM-dd");				
					
					//SQL para obter os totais por terminal
					sqlQuery = "SELECT DocumentsHeaders.Terminal, " +
							"       sum( DocumentsHeaders.Total + 0.000 ) AS Total " +
							" FROM DocumentsHeaders " +
							" WHERE date(CreationDate) = date( '" + date + "' )  " +
							" GROUP BY Terminal;";
					
					queryResultDT = Db.CurrentDatabase.GetDataTable(sqlQuery);

					// Criação do texto referente ao total por terminal
					for (int i = 0; i < queryResultDT.Rows.Count; i++)
					{
						if(i!=(queryResultDT.Rows.Count-1))
							docText = docText + "<td width='85%'><font face='Arial' color='#FFFFFF'>" + queryResultDT.Rows[i][0].ToString() + ":</font></td><td width='15%'><font face='Arial' color='#FFFFFF'>" + queryResultDT.Rows[i][1].ToString() + "€</font></td>" + "-";//Cada terminal lido
						else
							docText = docText + "<td width='85%'><font face='Arial' color='#FFFFFF'>" + queryResultDT.Rows[i][0].ToString() + ":</font></td><td width='15%'><font face='Arial' color='#FFFFFF'>" + queryResultDT.Rows[i][1].ToString() + "€</font></td>";//Ultimo terminal a ler
					}
					
				} else
				{
					//Se não existem dados para criar o ficheiro, este vai vazio
					docText = "";
				}
				
				//Escrever todo o texto até agora criado para um ficheiro
				System.IO.StreamWriter file = new System.IO.StreamWriter(@"C:\Backups\temp\stats.txt");
				file.WriteLine(docText);
				
				file.Close();
				
				//Fazer upload do ficheiro criado para o servidor ftp
				//O primeiro parametro é a localização do ficheiro
				//O segundo parametro é a localização que o ficheiro irá ter no ftp
				//O terceiro parametro é o nome de utilizador do ftp
				//O quarto parametro é a password do ftp
				UploadFile(@"C:\Backups\temp\stats.txt", "ftp://ftp.exemplo.pt:21/tmp/stats.txt", "utilizadorteste", "passwordteste");
			}
			catch(Exception e){
				MessageDG.ShowQuestionYesNo(null,"SCRIPT TESTE", e.Message );
				Console.WriteLine(e);
				
			}
	    }

		//Função para fazer upload de ficheiro para FTP
		public static void UploadFile(string _FileName, string _UploadPath, string _FTPUser, string _FTPPass)
		{
			System.IO.FileInfo _FileInfo = new System.IO.FileInfo(_FileName);
			
			// Criar objecto para ligar ao ftp
			System.Net.FtpWebRequest _FtpWebRequest = (System.Net.FtpWebRequest)System.Net.FtpWebRequest.Create(new Uri(_UploadPath));
			
			// Permissões do FTP
			_FtpWebRequest.Credentials = new System.Net.NetworkCredential(_FTPUser, _FTPPass);
			
			// Não manter a ligação aberta
			_FtpWebRequest.KeepAlive = false;
			
			// Timeout de 20 segundos
			_FtpWebRequest.Timeout = 20000;
			
			// Comando de upload
			_FtpWebRequest.Method = System.Net.WebRequestMethods.Ftp.UploadFile;
			
			// Transferencia binária
			_FtpWebRequest.UseBinary = true;
			
			// Notificar o servidor do tamanho do ficheiro
			_FtpWebRequest.ContentLength = _FileInfo.Length;
			
			// Buffer de 2kb
			int buffLength = 2048;
			byte[] buff = new byte[buffLength];
			
			// Criar objecto para ler ficheiro
			System.IO.FileStream _FileStream = _FileInfo.OpenRead();
			
			try
			{
				// Stream de upload
				System.IO.Stream _Stream = _FtpWebRequest.GetRequestStream();
				
				// Ler ficheiro 2kb de cada vez
				int contentLen = _FileStream.Read(buff, 0, buffLength);
				
				// Até não existir mais conteudo a ler
				while (contentLen != 0)
				{
					// Escreve o conteudo do ficheiro no stream
					_Stream.Write(buff, 0, contentLen);
					contentLen = _FileStream.Read(buff, 0, buffLength);
				}
				
				// Fechar os streams
				_Stream.Close();
				_Stream.Dispose();
				_FileStream.Close();
				_FileStream.Dispose();
			}
			catch (Exception ex)
			{
				Console.WriteLine(ex.Message, "Upload Error");
			}
		}

	}
}

