/*
 * Este script executa a função Backup e de seguida sai do software XD
 * Versão mínima do Software XD necessária - 1.0.26
 */

using System;

// Obrigatório
namespace XRest{

	// Obrigatório
	public class Script
	{
		// A função Execute é obrigatória em todos os scripts. É a partir de aqui que todo o código do script vai ser chamado.
	    public static void Execute (ScriptHost host)
		{
			// Variável necessária para verificar se o backup foi efectuado com sucesso
			int acabou;

			/* A função de backup pode ser iniciada  com BackupUtil.StartBackup(caminho, null).
			 * O caminho é o local onde o backup será guardado
			 * Neste caso vamos guardar o ficheiro de backup em C:
			 * A variável acabou irá guardar o resultado da função de backup
			 */

			acabou = BackupUtil.StartBackup ("C:\\", null);

			/* A função StartBackup(...,...) devolve 0 se for executada com sucesso e -1 se existir algum problema a executar
			 * Vamos então verificar se a função foi executada com sucesso
			 */

			if (acabou == 0) {

				/* Se a função executou com sucesso então entramos neste bloco
			 	 * E vamos correr a função para sair do programa e fazer shutdown do sistema operativo (shutdown apenas possivel em Windows)
			 	 */
				ItemsSelectionWT.GetInstance ().SAIR_SO (1);
			}
	    }
	}
}

